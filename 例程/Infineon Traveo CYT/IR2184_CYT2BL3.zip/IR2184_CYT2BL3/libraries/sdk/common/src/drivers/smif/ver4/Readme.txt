
V4_0 for C2D6M rev_b (onwards) and C2D6MDDR rev_a.

V4_0 represents SMIF_4_0
