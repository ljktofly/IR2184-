
V2_0 for BH4M and BH8M devices.

V2_0 represents SMIF_ver2
